#ifndef CAMERA_H
#define CAMERA_H
#include <ctime>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include "raspicam_cv.h"
#include <cv.h>

#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "objdetect.hpp"

#include <functional>
#include "stdafx.h"




using namespace std;
using namespace cv;

//!\brief In the class camera there are functions, which proccess images received from camera and calculate distances to tracked objects
//!\brief It includes commands: \sa processCommandLine \sa findParam \sa getParamVal \sa walk \sa red_ball
//!\sa draw_cont \sa camera_film \sa calculate_median
//!\sa camera  class camera  constructor
//!\sa ~camera class camera deconstructor
//!\class camera inherites from class stdafx  \sa stdafx
//!\class camera shares its results of calculation with the class robot \sa robot
class camera:public stdafx
{
    public:
        camera();
      void processCommandLine ( raspicam::RaspiCam_Cv &Camera );       //!< sets camera parameters according to user preferences

     void red_ball (Mat image_po_obrobce,Mat image_origin);                                                            //!< detects red ball
     int draw_cont(Mat& frame, Mat& image);                                                 //!< detects round object, draws rectangle contours around it and calculates distance from camera to object and from the center of the camera to center of the object and stores the results in vectors: distance_x and distance_y
     int camera_film( int nCount);                                                                     //!< captures the video,opens Trackbar to control colour and releases camera
    double distancex_cam, distancey_cam;                                                    //!< distancex_cam The calculated in milimeters value of distance between center of the round object detected and camera in x axis
                                                                                            //!< distancey_cam The calculated in milimeters value of distance between center of the round object detected and the center of camera in y axis
     void calculate_median();                                                               //!< calculates median values from distance vectors: distance_x and distance_y,which are created in function draw_cont   \sa draw_cont

   vector <int> distance_x,distance_y;                                                      //!< distance_x The vector type integer variable, which accumulates the calculated values of distance distancex_cam. It is used to calculate median in function \sa calcalculate_median
      vector <int> pomocnicza_do_value;
vector<int> pomocniczna_do_satu;
int k=0;                                                                                      //!< distance_y The vector type integer variable, which accumulates the calculated values of distance distancey_cam. It is used to calculate median in function \sa calcalculate_median

    double  dis_ball_from_camera,dis_ball_from_scr_center;                                                                         //!< vn The medium value of vector  distance_x. Given in centimeters
                                                                                            //!< vn1 The medium value of vector  distance_y.Given in centimeters
       int probe_indicator_for_camera;                                                      //!< the value 0 indicates that robot will go right,1 indicates that robot will go left
        vector <vector<Point> > contours;                                                   //!< Vector variable, which indicates if the round object is detected or not. It is used further to draw rectangle contours.



float a,b,c;
float previous_c=0;

 int origin(vector<Mat> img, int b, int e);
   int add_track(Mat img_origin, Mat img);

        virtual ~camera();

vector<Mat> pictures;
        vector<Mat> pictures1;
        vector<Mat> pictures2;
int wsk_obraz;
float c_max=0;
int temp_pos_minValue=100;
int temp_pos_minSat=130;
int minValueredab=temp_pos_minValue;
int minSaturedab=temp_pos_minSat;

    };

#endif // CAMERA_H
